import os
from ament_index_python.packages import get_package_share_directory
from launch import LaunchDescription
from launch_ros.actions import Node

def generate_launch_description():
   config = os.path.join( #Obtenemos la ruta al archivo .yaml
   	get_package_share_directory('setpoint'),
                               	'config',
                               	'params.yaml')
   
   setpoint_generator = Node( #Guardamos en una variable el nodo 
   	package='setpoint',       #que deseamos lanzar
   	executable='setpoint_team2',
   	output='screen',
   	parameters=[config]
   )

   #Usando una nueva variable, usamos LaunchDescription para idnicar todos los nodos
   #a inicializar (en este caso solo es uno)
   l_d = LaunchDescription([setpoint_generator])
   
   return l_d
