import rclpy
import numpy as np
import time 
from scipy import signal
from rclpy.node import Node
from std_msgs.msg import Float32

class Setpoint_Generator(Node): 
    def __init__(self): 
        super().__init__('setpoint_2') #Nombre del nodo
        self.declare_parameters( #Parametros del nodo, asociados con las señales del setpoint
            namespace='',
            parameters = [
                ('selection', rclpy.Parameter.Type.INTEGER), ('sine_frequency', rclpy.Parameter.Type.DOUBLE),
                ('sawtooth_frequency', rclpy.Parameter.Type.DOUBLE), ('constant_value', rclpy.Parameter.Type.DOUBLE) , 
                ('square_frequency', rclpy.Parameter.Type.DOUBLE)
            ]
        )

        #Publicador para el setpoint:
        self.setpoint_pub = self.create_publisher(Float32, 'setpoint_2', 10)
        setpoint_period = 0.01 #Señal publicada a 100hz (100 datos por segundo)

        #Timer para publicar setpoint
        self.timer_setpoint = self.create_timer(setpoint_period, self.setpoint_callback)

        #Variable para el setpoint
        self.setpoint_value = Float32()

        #Mensaje de inicialización 
        self.get_logger().info("Setpoint generator succesfully initialized !")
        
    def setpoint_callback(self): 
        t = time.time()
        #Obtenemos la señal solicitada por el usuario: 
        selection = self.get_parameter('selection').get_parameter_value().integer_value

        if(selection>4 or selection<=0):
            selection = 1 #Asegurar la selección dentro del rango
        
        #Calculamos la señal acorde a los parametros y la selecicón: 
        if(selection == 1): #Constant: 
            self.setpoint_value.data = self.get_parameter('constant_value').get_parameter_value().double_value
        elif(selection == 2): #Sine
            frequency = self.get_parameter('sine_frequency').get_parameter_value().double_value
            self.setpoint_value.data = np.sin(2*np.pi*frequency*t)
        elif(selection == 3): #Sawtooth
            frequency = self.get_parameter('sawtooth_frequency').get_parameter_value().double_value
            self.setpoint_value.data = float(signal.sawtooth(2 * np.pi * frequency * t, 0.5))
        elif(selection == 4): #Square
            frequency = self.get_parameter('square_frequency').get_parameter_value().double_value
            self.setpoint_value.data = 0.2*(float(signal.square(2* np.pi * frequency *t)))
        #Publicamos el setpoint
        self.setpoint_pub.publish(self.setpoint_value)

def main(): 
    #EJecución del nodo 
    rclpy.init()
    s_g = Setpoint_Generator()
    rclpy.spin(s_g)
    s_g.destroy_node
    rclpy.shutdown()

if __name__ == '__main__': 
    main()